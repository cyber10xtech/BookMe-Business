import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate, useNavigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { setupDeepLinks } from "@/services/native";
import PermissionsModal from "@/components/PermissionsModal";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect, useState } from "react";
import React, { Suspense, lazy } from "react";
import logo from "@/assets/logo.jpg";

const SignIn = lazy(() => import("./pages/SignIn"));
const Register = lazy(() => import("./pages/Register"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const CalendarPage = lazy(() => import("./pages/CalendarPage"));
const HomePage = lazy(() => import("./pages/HomePage"));
const MorePage = lazy(() => import("./pages/MorePage"));
const ClientsPage = lazy(() => import("./pages/ClientsPage"));
const ChatsPage = lazy(() => import("./pages/ChatsPage"));
const NotificationsPage = lazy(() => import("./pages/NotificationsPage"));
const EditProfilePage = lazy(() => import("./pages/EditProfilePage"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient();

const DeepLinkHandler = () => {
  const navigate = useNavigate();
  useEffect(() => { setupDeepLinks(navigate); }, [navigate]);
  return null;
};

// Single splash screen rendered at the top level while auth is resolving.
// Once loading is false it unmounts — pages render underneath with no further logo flashes.
const SplashGate = ({ children }: { children: React.ReactNode }) => {
  const { loading } = useAuth();
  // Keep splash visible until auth resolves, then fade out smoothly.
  const [visible, setVisible] = useState(true);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    if (!loading) {
      setFading(true);
      const t = setTimeout(() => setVisible(false), 300); // match CSS transition
      return () => clearTimeout(t);
    }
  }, [loading]);

  return (
    <>
      {children}
      {visible && (
        <div
          className="fixed inset-0 z-50 bg-background flex items-center justify-center"
          style={{
            transition: "opacity 300ms ease",
            opacity: fading ? 0 : 1,
            pointerEvents: fading ? "none" : "all",
          }}
        >
          <img src={logo} alt="BookMe" className="w-32 h-32" />
        </div>
      )}
    </>
  );
};

const AuthGuard = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  // Auth is still resolving — SplashGate above is covering the screen, render nothing.
  if (loading) return null;
  if (!user) return <Navigate to="/signin" replace />;
  return <>{children}</>;
};

// Waits for auth then routes to the right place — no logo here, SplashGate covers it.
const RootRedirect = () => {
  const { user, loading } = useAuth();
  if (loading) return null;
  return <Navigate to={user ? "/dashboard" : "/signin"} replace />;
};

const AppInner = () => (
  // Suspense fallback is null — SplashGate covers initial load.
  // For subsequent lazy navigations the page loads silently.
  <SplashGate>
    <DeepLinkHandler />
    <PermissionsModal />
    <Suspense fallback={null}>
      <Routes>
        <Route path="/" element={<RootRedirect />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<AuthGuard><Dashboard /></AuthGuard>} />
        <Route path="/calendar" element={<AuthGuard><CalendarPage /></AuthGuard>} />
        <Route path="/home" element={<AuthGuard><HomePage /></AuthGuard>} />
        <Route path="/more" element={<AuthGuard><MorePage /></AuthGuard>} />
        <Route path="/clients" element={<AuthGuard><ClientsPage /></AuthGuard>} />
        <Route path="/chats" element={<AuthGuard><ChatsPage /></AuthGuard>} />
        <Route path="/notifications" element={<AuthGuard><NotificationsPage /></AuthGuard>} />
        <Route path="/edit-profile" element={<AuthGuard><EditProfilePage /></AuthGuard>} />
        <Route path="/messages" element={<Navigate to="/chats" replace />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  </SplashGate>
);

// Keys AppInner off the user ID so React fully unmounts all hooks/state
// the moment the session changes — the nuclear guarantee against stale data.
const AppInnerKeyed = () => {
  const { user } = useAuth();
  return <AppInner key={user?.id ?? "unauthenticated"} />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AuthProvider>
        <BrowserRouter>
          <AppInnerKeyed />
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
