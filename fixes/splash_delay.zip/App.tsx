import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate, useNavigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { setupDeepLinks } from "@/services/native";
import PermissionsModal from "@/components/PermissionsModal";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect, useState } from "react";
import React, { Suspense, lazy } from "react";
import logo from "@/assets/logo.jpg";
// SignIn + Register are eagerly bundled — unauthenticated entry points must
// render immediately without any lazy-load delay or splash screen.
import SignInPage from "./pages/SignIn";
import RegisterPage from "./pages/Register";

const Dashboard = lazy(() => import("./pages/Dashboard"));
const CalendarPage = lazy(() => import("./pages/CalendarPage"));
const HomePage = lazy(() => import("./pages/HomePage"));
const MorePage = lazy(() => import("./pages/MorePage"));
const ClientsPage = lazy(() => import("./pages/ClientsPage"));
const ChatsPage = lazy(() => import("./pages/ChatsPage"));
const NotificationsPage = lazy(() => import("./pages/NotificationsPage"));
const EditProfilePage = lazy(() => import("./pages/EditProfilePage"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient();

const DeepLinkHandler = () => {
  const navigate = useNavigate();
  useEffect(() => { setupDeepLinks(navigate); }, [navigate]);
  return null;
};

// Renders nothing but calls onReady() once on mount — after Suspense resolves.
// This is how we signal SplashGate that the lazy chunk has finished loading.
const ChunkReadySignal = ({ onReady }: { onReady: () => void }) => {
  useEffect(() => { onReady(); }, [onReady]);
  return null;
};

// While the lazy chunk is still downloading, ChunkPending renders nothing.
// SplashGate is covering the screen anyway so the blank is invisible.
const ChunkPending = () => null;

// SplashGate stays visible until BOTH auth resolves AND the first lazy page
// chunk has finished loading — so the splash bridges cold-start auth check
// AND the lazy load of the target page (e.g. Dashboard on a returning user).
// On the sign-in path, SignIn is eagerly bundled so chunkReady fires instantly.
const SplashGate = ({ children, chunkReady }: { children: React.ReactNode; chunkReady: boolean }) => {
  const { loading: authLoading } = useAuth();
  const [visible, setVisible] = useState(true);
  const [fading, setFading] = useState(false);

  const canHide = !authLoading && chunkReady;

  useEffect(() => {
    if (canHide) {
      setFading(true);
      const t = setTimeout(() => setVisible(false), 300);
      return () => clearTimeout(t);
    }
  }, [canHide]);

  return (
    <>
      {children}
      {visible && (
        <div
          className="fixed inset-0 z-50 bg-background flex items-center justify-center"
          style={{
            transition: "opacity 300ms ease",
            opacity: fading ? 0 : 1,
            pointerEvents: fading ? "none" : "all",
          }}
        >
          <img src={logo} alt="BookMe" className="w-32 h-32" />
        </div>
      )}
    </>
  );
};

const AuthGuard = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  // Auth is still resolving — SplashGate above is covering the screen, render nothing.
  if (loading) return null;
  if (!user) return <Navigate to="/signin" replace />;
  return <>{children}</>;
};

// Waits for auth then routes to the right place — no logo here, SplashGate covers it.
const RootRedirect = () => {
  const { user, loading } = useAuth();
  if (loading) return null;
  return <Navigate to={user ? "/dashboard" : "/signin"} replace />;
};

const AppInner = () => {
  // chunkReady flips true the first time the lazy page chunk finishes loading.
  // SplashGate waits for this before fading out.
  const [chunkReady, setChunkReady] = useState(false);
  // Stable ref so ChunkReadySignal's useEffect dep array never changes.
  const markReady = React.useCallback(() => setChunkReady(true), []);

  return (
  <SplashGate chunkReady={chunkReady}>
    <DeepLinkHandler />
    <PermissionsModal />
    {/* ChunkReadySignal mounts only after Suspense resolves, flipping chunkReady. */}
    <Suspense fallback={<ChunkPending />}>
      <Routes>
        <Route path="/" element={<RootRedirect />} />
        <Route path="/signin" element={<SignInPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/dashboard" element={<AuthGuard><Dashboard /></AuthGuard>} />
        <Route path="/calendar" element={<AuthGuard><CalendarPage /></AuthGuard>} />
        <Route path="/home" element={<AuthGuard><HomePage /></AuthGuard>} />
        <Route path="/more" element={<AuthGuard><MorePage /></AuthGuard>} />
        <Route path="/clients" element={<AuthGuard><ClientsPage /></AuthGuard>} />
        <Route path="/chats" element={<AuthGuard><ChatsPage /></AuthGuard>} />
        <Route path="/notifications" element={<AuthGuard><NotificationsPage /></AuthGuard>} />
        <Route path="/edit-profile" element={<AuthGuard><EditProfilePage /></AuthGuard>} />
        <Route path="/messages" element={<Navigate to="/chats" replace />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      {/* Mounts after Suspense resolves — signals splash to fade */}
      <ChunkReadySignal onReady={markReady} />
    </Suspense>
  </SplashGate>
  );
};

// Keys AppInner off the user ID so React fully unmounts all hooks/state
// the moment the session changes — the nuclear guarantee against stale data.
const AppInnerKeyed = () => {
  const { user } = useAuth();
  return <AppInner key={user?.id ?? "unauthenticated"} />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AuthProvider>
        <BrowserRouter>
          <AppInnerKeyed />
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
